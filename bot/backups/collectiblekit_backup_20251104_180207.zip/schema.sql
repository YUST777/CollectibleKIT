-- CollectibleKIT Database Schema
-- Generated: 2025-11-04T18:02:07.630731

CREATE TABLE users (
          user_id INTEGER PRIMARY KEY,
          username TEXT,
          first_name TEXT,
          free_uses INTEGER DEFAULT 0,
          credits INTEGER DEFAULT 0,
          created_at REAL DEFAULT 0,
          last_activity REAL DEFAULT 0,
          user_type TEXT DEFAULT 'normal',
          watermark BOOLEAN DEFAULT 0
        , streak_days INTEGER DEFAULT 0, last_streak_click TEXT, streak_completed BOOLEAN DEFAULT 0, premium_expires_at INTEGER DEFAULT NULL, ton_balance REAL DEFAULT 0, first_win_claimed INTEGER DEFAULT 0, daily_wins_count INTEGER DEFAULT 0, last_win_date TEXT, wallet_address TEXT);

CREATE TABLE payments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          memo TEXT UNIQUE,
          amount_nano INTEGER,
          credits_to_grant INTEGER,
          status TEXT DEFAULT 'pending',
          created_at REAL,
          completed_at REAL DEFAULT NULL,
          transaction_hash TEXT DEFAULT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE requests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          request_type TEXT,
          image_size TEXT,
          pieces_count INTEGER,
          watermarked BOOLEAN,
          credits_used INTEGER DEFAULT 0,
          created_at REAL,
          processing_time REAL DEFAULT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE saved_collections (
          id TEXT PRIMARY KEY,
          user_id INTEGER,
          name TEXT NOT NULL,
          designs TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_public BOOLEAN DEFAULT 0,
          likes_count INTEGER DEFAULT 0,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE collection_likes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          collection_id TEXT NOT NULL,
          user_id INTEGER NOT NULL,
          created_at REAL NOT NULL,
          FOREIGN KEY (collection_id) REFERENCES saved_collections (id),
          FOREIGN KEY (user_id) REFERENCES users (user_id),
          UNIQUE(collection_id, user_id)
        );

CREATE TABLE daily_game_rewards (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          date TEXT,
          time_slot TEXT,
          amount REAL,
          tx_hash TEXT,
          paid_at REAL DEFAULT 0,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE sales (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          payment_id INTEGER,
          amount_ton REAL,
          credits_purchased INTEGER,
          completed_at REAL,
          FOREIGN KEY (user_id) REFERENCES users (user_id),
          FOREIGN KEY (payment_id) REFERENCES payments (id)
        );

CREATE TABLE referrals (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          referrer_id INTEGER NOT NULL,
          invited_id INTEGER NOT NULL,
          invited_name TEXT DEFAULT '',
          invited_photo TEXT DEFAULT '',
          created_at REAL NOT NULL,
          FOREIGN KEY (referrer_id) REFERENCES users (user_id),
          FOREIGN KEY (invited_id) REFERENCES users (user_id),
          UNIQUE(referrer_id, invited_id)
        );

CREATE TABLE tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          task_id TEXT UNIQUE NOT NULL,
          title TEXT NOT NULL,
          description TEXT NOT NULL,
          category TEXT NOT NULL,
          credits_reward INTEGER NOT NULL,
          is_daily BOOLEAN DEFAULT 0,
          is_active BOOLEAN DEFAULT 1,
          created_at REAL NOT NULL
        );

CREATE TABLE feed_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            first_name TEXT,
            event_type TEXT NOT NULL,
            event_data TEXT,
            created_at INTEGER NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE game_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stat_key TEXT UNIQUE NOT NULL,
            stat_value INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL
        );

CREATE TABLE task_completions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          task_id TEXT NOT NULL,
          completed_at REAL NOT NULL,
          credits_earned INTEGER NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id),
          FOREIGN KEY (task_id) REFERENCES tasks (task_id),
          UNIQUE(user_id, task_id, completed_at)
        );

CREATE TABLE user_task_progress (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          task_id TEXT NOT NULL,
          progress_data TEXT DEFAULT '{}',
          last_updated REAL NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id),
          FOREIGN KEY (task_id) REFERENCES tasks (task_id),
          UNIQUE(user_id, task_id)
        );

CREATE TABLE daily_withdrawals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        withdrawal_date DATE NOT NULL,
                        amount_ton REAL NOT NULL,
                        transaction_id TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(user_id, withdrawal_date)
                    );

CREATE TABLE user_premium_status (
                        user_id INTEGER PRIMARY KEY,
                        is_premium BOOLEAN DEFAULT FALSE,
                        premium_until TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );

CREATE TABLE ton_transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        transaction_id TEXT UNIQUE NOT NULL,
                        user_id INTEGER NOT NULL,
                        amount_ton REAL NOT NULL,
                        transaction_type TEXT NOT NULL,
                        wallet_address TEXT NOT NULL,
                        tx_hash TEXT,
                        memo TEXT,
                        status TEXT DEFAULT 'pending',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );

CREATE TABLE memo_data (
                        short_id TEXT PRIMARY KEY,
                        user_id INTEGER NOT NULL,
                        amount_ton REAL NOT NULL,
                        transaction_type TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );

CREATE TABLE daily_game_questions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT,
                    time_slot TEXT,
                    question_type TEXT,
                    question_data TEXT,
                    created_at REAL,
                    UNIQUE(date, time_slot)
                );

CREATE TABLE interactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    interaction_type TEXT,  -- 'start', 'free_plan', 'paid_plan', 'photo_upload', 'command', etc.
                    data TEXT DEFAULT NULL,  -- JSON data for additional context
                    created_at REAL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );

CREATE TABLE user_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    session_start REAL,
                    session_end REAL DEFAULT NULL,
                    interactions_count INTEGER DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );

CREATE TABLE broadcasts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    message_text TEXT NOT NULL,
                    total_sent INTEGER DEFAULT 0,
                    total_failed INTEGER DEFAULT 0,
                    created_at REAL NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                );

CREATE TABLE "daily_game_solves" (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        time_slot TEXT NOT NULL,
        answer TEXT NOT NULL,
        is_first_solver BOOLEAN NOT NULL DEFAULT 0,
        solved_at REAL NOT NULL,
        UNIQUE(user_id, date, time_slot)
    );

CREATE TABLE portfolio_custom_gifts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          slug TEXT NOT NULL,
          title TEXT NOT NULL,
          num INTEGER,
          model_name TEXT,
          backdrop_name TEXT,
          pattern_name TEXT,
          model_rarity REAL,
          backdrop_rarity REAL,
          pattern_rarity REAL,
          price REAL,
          availability_issued INTEGER,
          availability_total INTEGER,
          total_supply TEXT,
          created_at REAL NOT NULL, owner_username TEXT, owner_name TEXT,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE portfolio_auto_gifts_cache (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL UNIQUE,
          gifts_data TEXT NOT NULL,
          total_value REAL NOT NULL,
          cached_at REAL NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE portfolio_rate_limit (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL UNIQUE,
          last_refresh REAL NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE portfolio_custom_stickers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          collection TEXT NOT NULL,
          character TEXT NOT NULL,
          token_id TEXT,
          init_price_usd REAL,
          current_price_usd REAL,
          created_at REAL NOT NULL, filename TEXT,
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

CREATE TABLE portfolio_channel_gifts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          channel_username TEXT NOT NULL,
          channel_id TEXT,
          total_gifts INTEGER NOT NULL,
          total_value REAL NOT NULL,
          gifts_json TEXT NOT NULL,
          created_at REAL NOT NULL, type TEXT DEFAULT 'channel',
          FOREIGN KEY (user_id) REFERENCES users (user_id)
        );

